**EXAMPLE FILE**

	cm	cardinal	noun	cm	adjective;
