**EXAMPLE FILE**

	cm	noun	verb_aux	verb_aux	verb;
	noun	verb	SYM	noun	verb_aux;
	cm	noun	verb_aux	verb_aux	verb;
	particle	noun	verb_aux	SYM	verb;
	cm	verb	verb_aux	verb_aux	verb_aux;
	conj	neg	verb_aux	conj	verb;
	cm	nst	verb_aux	SYM	verb;
	cm	noun	SYM	noun	verb;
	cm	noun	verb_aux	verb_aux	verb;
	adjective	noun	verb_aux	pn	verb;
	cm	noun	verb_aux	SYM	verb;
	noun	verb	SYM	adverb	verb_aux;
	adjective	noun	verb	cm	verb;
	pn	noun	verb_aux	SYM	verb;
	neg	verb	SYM	SYM	verb_aux;
	adjective	verb	SYM	nst	verb_aux;
	noun	verb	SYM	pn	verb_aux;
	noun	noun	verb_aux	SYM	verb;
	cm	noun	verb_aux	verb_aux	verb;
	adjective	noun	verb	cm	verb;
	noun	particle	verb_aux	SYM	verb;
	cm	noun	demonstrative	noun	verb;
	cm	noun	verb_aux	verb_aux	verb;
