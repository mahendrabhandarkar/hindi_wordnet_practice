**EXAMPLE FILE**

	verb	verb_aux	noun	SYM	verb_aux;
	nst	verb	noun	cm	cm;
	cm	noun	noun	cm	adjective;
	SYM	verb	noun	cm	cm;
	noun	verb	verb_aux	SYM	verb_aux;
	nst	verb	noun	cm	adjective;
	adjective	verb	noun	cm	cm;
	noun	verb	noun	cardinal	cm;
	cm	verb	noun	cm	adjective;
	pnoun	verb	noun	noun	cm;
	noun	verb	noun	adjective	cm;
	noun	verb	demonstrative	noun	cm;
	cardinal	noun	noun	noun	adjective;
	adjective	noun	noun	noun	adjective;
	cm	noun	noun	verb	adjective;
	verb	verb	noun	verb	cm;
	pn	verb	adverb	pn	cm;
	noun	verb	SYM	cardinal	adjective;
	noun	verb	pnoun	pnoun	adjective;
	noun	verb	noun	pnoun	adjective;
	noun	verb	quantifier	noun	adjective;
	noun	verb	noun	noun	adjective;
	pn	verb	noun	neg	adjective;
	noun	verb	noun	noun	adjective;
	cm	noun	noun	pnoun	cm;
