**EXAMPLE FILE**

	cm	noun	nst	noun	particle;
	cardinal	adjective	adjective	noun	particle;
	P_wh	SYM	noun	noun	particle;
	conj	noun	cm	cardinal	cm;
	SYM	noun	cm	SYM	particle;
	cm	noun	cm	noun	particle;
