**EXAMPLE FILE**

	pn	particle	cardinal	noun	quantifier;
	SYM	pnoun	noun	cm	noun;
