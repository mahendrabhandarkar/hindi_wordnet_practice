**EXAMPLE FILE**

	adjective	verb	verb_aux	conj	verb;
	pn	quantifier	pnoun	pnoun	verb;
	pnoun	cm	noun	cm	verb;
	adverb	particle	noun	verb	verb;
	quantifier	noun	verb_aux	SYM	verb;
	verb_aux	cm	verb	verb_aux	adjective;
	adjective	pnoun	verb_aux	cm	verb;
	noun	cm	verb_aux	conj	verb;
	noun	cm	verb_aux	conj	verb;
	pnoun	cm	noun	cm	verb;
	noun	demonstrative	verb_aux	noun	verb;
	noun	cm	SYM	noun	verb;
	demonstrative	noun	verb_aux	verb_aux	verb;
	quantifier	particle	adjective	noun	adjective;
	particle	adjective	noun	cm	adjective;
	pn	neg	pn	noun	verb;
	noun	cm	verb_aux	verb_aux	verb;
	verb_aux	pn	neg	verb	adjective;
	cm	noun	verb_aux	conj	verb;
	noun	cm	noun	verb	adjective;
	verb	cm	verb_aux	verb_aux	verb;
	adjective	P_wh	verb_aux	verb_aux	verb;
	demonstrative	noun	pn	noun	verb;
	cm	noun	verb_aux	conj	verb;
