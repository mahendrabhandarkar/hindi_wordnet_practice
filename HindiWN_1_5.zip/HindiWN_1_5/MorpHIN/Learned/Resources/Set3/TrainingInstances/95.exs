**EXAMPLE FILE**

	noun	conj	pnoun	pnoun	noun;
