**EXAMPLE FILE**

	cm	pn	verb	pnoun	quantifier;
	cm	pn	noun	adjective	quantifier;
	cm	particle	pnoun	noun	quantifier;
	noun	cm	particle	quantifier	quantifier;
	quantifier	particle	adverb	noun	quantifier;
	cardinal	cm	noun	cm	quantifier;
	noun	cm	noun	cm	quantifier;
	cardinal	cm	adjective	verb	quantifier;
	pnoun	cm	adjective	verb	quantifier;
	cardinal	particle	noun	cm	quantifier;
	cardinal	cm	noun	cm	quantifier;
	noun	cm	pnoun	noun	quantifier;
	cm	pn	noun	adjective	quantifier;
