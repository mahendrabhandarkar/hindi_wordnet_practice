**EXAMPLE FILE**

	pnoun	cm	adjective	noun	nst;
	conj	pn	noun	noun	nst;
	pnoun	cm	adjective	noun	nst;
	pnoun	cm	adjective	noun	nst;
	conj	pn	cardinal	noun	nst;
	conj	pn	quantifier	quantifier	nst;
	noun	cm	verb	SYM	nst;
