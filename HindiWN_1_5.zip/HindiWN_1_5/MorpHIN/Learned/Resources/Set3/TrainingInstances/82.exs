**EXAMPLE FILE**

	particle	quantifier	particle	SYM	adjective;
	cm	verb	pnoun	cm	adverb;
