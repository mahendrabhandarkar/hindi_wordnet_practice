**EXAMPLE FILE**

	SYM	pn	SYM	noun	adjective;
	quantifier	noun	verb	verb_aux	adjective;
	verb	conj	noun	neg	adjective;
	quantifier	quantifier	verb	particle	adjective;
	pn	pn	noun	verb	adjective;
