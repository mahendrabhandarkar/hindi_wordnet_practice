**EXAMPLE FILE**

	cm	cm	noun	verb	P_wh;
	cm	conj	pn	demonstrative	P_wh;
	conj	pn	noun	verb	P_wh;
	noun	cm	verb	verb_aux	P_wh;
	verb	cm	verb	verb_aux	P_wh;
	noun	cm	verb	verb_aux	P_wh;
	SYM	pn	verb	pn	P_wh;
	conj	particle	demonstrative	noun	P_wh;
	conj	adverb	verb	SYM	P_wh;
	cm	noun	noun	verb	P_wh;
	cm	pn	noun	verb	P_wh;
	cm	noun	verb	SYM	P_wh;
