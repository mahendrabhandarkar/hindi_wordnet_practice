**EXAMPLE FILE**

	conj	adjective	particle	pnoun	adverb;
	conj	intensifier	particle	verb	adverb;
	verb_aux	conj	cm	pn	noun;
	noun	cm	noun	verb	noun;
