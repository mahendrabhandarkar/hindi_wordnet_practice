**EXAMPLE FILE**

	verb	SYM	particle	adjective	adjective;
	verb	verb_aux	particle	pn	conj;
