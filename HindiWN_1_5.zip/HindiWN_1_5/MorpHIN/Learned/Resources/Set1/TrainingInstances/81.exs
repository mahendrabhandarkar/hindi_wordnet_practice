**EXAMPLE FILE**

	cardinal	pnoun	pnoun	cm	nst;
	noun	conj	verb	cm	nst;
	pn	cm	verb	verb_aux	nst;
	particle	quantifier	particle	SYM	adjective;
	cm	verb	pnoun	cm	adverb;
