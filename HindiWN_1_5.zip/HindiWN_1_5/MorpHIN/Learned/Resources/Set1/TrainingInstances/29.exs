**EXAMPLE FILE**

	noun	cm	verb	verb_aux	adjective;
	adjective	noun	verb	verb_aux	adjective;
	cm	noun	verb	cm	adjective;
	noun	verb	verb	SYM	adjective;
	cardinal	noun	verb	verb_aux	adjective;
	nst	particle	verb	verb_aux	adjective;
	noun	verb	verb	conj	adjective;
	noun	noun	verb	verb_aux	adjective;
	conj	particle	verb	verb_aux	adjective;
