**EXAMPLE FILE**

	verb	conj	pn	cm	demonstrative;
	noun	cm	noun	cm	quantifier;
	pn	particle	noun	pnoun	quantifier;
	verb	SYM	noun	noun	quantifier;
	noun	cm	noun	cm	quantifier;
	pnoun	cm	noun	quantifier	quantifier;
