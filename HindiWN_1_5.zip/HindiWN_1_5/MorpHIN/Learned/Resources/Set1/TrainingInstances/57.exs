**EXAMPLE FILE**

	pn	noun	verb	SYM	P_wh;
	cm	adjective	verb	verb_aux	P_wh;
