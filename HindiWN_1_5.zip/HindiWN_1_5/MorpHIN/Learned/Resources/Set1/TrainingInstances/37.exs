**EXAMPLE FILE**

	noun	neg	conj	adjective	verb;
	cm	SYM	SYM	noun	cm;
