**EXAMPLE FILE**

	noun	cm	pnoun	cm	cm;
	noun	cm	noun	verb	cm;
