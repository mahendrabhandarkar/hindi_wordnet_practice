**EXAMPLE FILE**

	conj	noun	neg	SYM	adjective;
