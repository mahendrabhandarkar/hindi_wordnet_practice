**EXAMPLE FILE**

	noun	cm	noun	verb	P_wh;
