**EXAMPLE FILE**

	adverb	conj	noun	adjective	cm;
	demonstrative	noun	noun	noun	neg;
	cm	cm	pnoun	noun	adverb;
	conj	pn	noun	cm	adverb;
