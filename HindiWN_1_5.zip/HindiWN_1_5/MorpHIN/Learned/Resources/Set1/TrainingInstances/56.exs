**EXAMPLE FILE**

	noun	cm	particle	verb	pn;
	noun	cm	verb	cm	verb;
