**EXAMPLE FILE**

	SYM	noun	SYM	adverb	particle;
