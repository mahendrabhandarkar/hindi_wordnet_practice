**EXAMPLE FILE**

	pnoun	cm	noun	pnoun	adjective;
	particle	pn	noun	pnoun	adjective;
