**EXAMPLE FILE**

	pn	quantifier	cm	adjective	adjective;
	noun	cm	verb	cardinal	adjective;
	pnoun	cm	noun	verb	adjective;
	conj	pn	adjective	noun	adjective;
