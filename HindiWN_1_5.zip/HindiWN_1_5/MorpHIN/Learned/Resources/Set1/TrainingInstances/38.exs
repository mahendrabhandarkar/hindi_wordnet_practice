**EXAMPLE FILE**

	adjective	noun	verb	verb_aux	quantifier;
	SYM	cardinal	noun	SYM	quantifier;
	verb	SYM	noun	adjective	quantifier;
	cardinal	cm	noun	noun	quantifier;
	particle	noun	noun	cm	quantifier;
	verb	cm	noun	cm	adjective;
	noun	cm	noun	verb	adjective;
	noun	cm	noun	noun	quantifier;
