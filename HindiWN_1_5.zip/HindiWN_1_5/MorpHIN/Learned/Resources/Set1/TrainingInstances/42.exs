**EXAMPLE FILE**

	noun	cm	adjective	noun	cm;
	pnoun	cm	verb	noun	cm;
	pnoun	cm	cardinal	SYM	cm;
	pnoun	cm	pn	noun	cm;
	pnoun	cm	noun	noun	cm;
	pnoun	cm	noun	verb	cm;
	SYM	pn	noun	noun	cm;
	noun	cm	verb	verb_aux	adjective;
	pnoun	cm	verb	cm	adjective;
	pnoun	cm	adjective	noun	cm;
	pnoun	cm	noun	cm	cm;
	cm	pn	quantifier	adjective	cm;
	SYM	pn	quantifier	particle	cm;
	noun	cm	noun	verb	cm;
	pnoun	cm	noun	adjective	cm;
	pnoun	cm	adjective	cardinal	cm;
	conj	pn	noun	verb	cm;
	conj	pn	noun	verb	cm;
	pnoun	cm	adjective	noun	cm;
	SYM	pn	noun	noun	cm;
	pnoun	cm	demonstrative	noun	cm;
	pnoun	cm	ordinal	adjective	cm;
	SYM	pn	demonstrative	noun	cm;
	pnoun	cm	noun	noun	cm;
	noun	cm	noun	adjective	cm;
	noun	cm	verb	SYM	adjective;
