**EXAMPLE FILE**

	cardinal	cm	adjective	verb	quantifier;
	pnoun	cm	adjective	verb	quantifier;
	cardinal	particle	noun	cm	quantifier;
	cardinal	cm	noun	cm	quantifier;
	noun	cm	pnoun	noun	quantifier;
	cm	particle	noun	SYM	quantifier;
	pn	intensifier	noun	verb	quantifier;
	cm	pn	noun	adjective	quantifier;
