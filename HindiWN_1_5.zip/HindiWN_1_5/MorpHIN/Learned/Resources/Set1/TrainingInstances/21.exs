**EXAMPLE FILE**

	SYM	SYM	noun	cardinal	adjective;
	cm	cardinal	noun	cm	adjective;
