**EXAMPLE FILE**

	cm	noun	cm	adjective	adjective;
