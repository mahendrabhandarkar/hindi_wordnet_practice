**EXAMPLE FILE**

	cm	nst	noun	noun	cm;
	adverb	conj	noun	adjective	cm;
	cm	cm	pnoun	noun	adverb;
	conj	pn	noun	cm	adverb;
