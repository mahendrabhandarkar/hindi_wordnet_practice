**EXAMPLE FILE**

	cm	noun	nst	noun	particle;
	SYM	noun	cm	adjective	particle;
	conj	pnoun	conj	adjective	particle;
	SYM	noun	cm	SYM	particle;
	cm	noun	cm	noun	particle;
