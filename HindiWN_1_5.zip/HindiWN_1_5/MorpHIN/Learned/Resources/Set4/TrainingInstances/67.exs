**EXAMPLE FILE**

	noun	verb	pnoun	cm	conj;
	verb	verb_aux	demonstrative	pnoun	conj;
	adjective	verb	pnoun	pn	conj;
	conj	noun	adverb	cm	conj;
	verb	verb_aux	pn	noun	conj;
	neg	verb	pnoun	pn	conj;
	verb	verb_aux	pn	particle	conj;
	demonstrative	noun	neg	verb	conj;
	neg	verb	adjective	noun	conj;
	noun	cm	pnoun	cm	particle;
	verb	verb_aux	noun	quantifier	conj;
	noun	verb	adjective	verb	conj;
	verb	verb_aux	demonstrative	noun	conj;
	verb	verb_aux	particle	demonstrative	conj;
	neg	verb	pn	noun	conj;
	nst	verb	noun	pnoun	conj;
	adjective	verb	pnoun	cm	conj;
	SYM	cardinal	pnoun	pnoun	particle;
	SYM	pn	quantifier	noun	particle;
	cm	conj	adjective	verb	particle;
