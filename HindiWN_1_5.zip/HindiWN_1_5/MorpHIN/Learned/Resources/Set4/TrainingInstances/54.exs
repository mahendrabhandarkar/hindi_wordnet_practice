**EXAMPLE FILE**

	verb	noun	verb	verb_aux	pn;
	noun	cm	cm	nst	pn;
	verb	conj	noun	cm	pn;
	conj	pnoun	demonstrative	noun	pn;
	noun	cm	noun	verb	pn;
