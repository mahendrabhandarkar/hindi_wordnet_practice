**EXAMPLE FILE**

	conj	pnoun	noun	noun	pn;
	verb_aux	conj	noun	verb	pn;
	verb_aux	conj	noun	verb	pn;
	cm	particle	noun	verb	pn;
	conj	pnoun	noun	verb	pn;
	cm	cm	noun	quantifier	pn;
	pnoun	cm	ordinal	pnoun	pn;
	cm	noun	noun	P_wh	pn;
	noun	cm	noun	verb	pn;
	particle	cm	pn	adjective	pn;
	pnoun	cm	adjective	noun	pn;
	cm	nst	noun	adjective	pn;
	cm	noun	quantifier	noun	pn;
