**EXAMPLE FILE**

	noun	cm	conj	particle	adverb;
	noun	cm	particle	verb	pn;
