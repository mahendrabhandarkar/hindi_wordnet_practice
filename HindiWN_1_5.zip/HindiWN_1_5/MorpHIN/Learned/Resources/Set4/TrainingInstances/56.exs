**EXAMPLE FILE**

	verb	conj	adjective	noun	quantifier;
	adjective	noun	noun	demonstrative	adverb;
	pn	cm	noun	cm	quantifier;
	noun	SYM	noun	cm	adverb;
	cm	noun	adjective	noun	adverb;
	cm	nst	noun	cm	adverb;
	adjective	noun	noun	verb	adverb;
