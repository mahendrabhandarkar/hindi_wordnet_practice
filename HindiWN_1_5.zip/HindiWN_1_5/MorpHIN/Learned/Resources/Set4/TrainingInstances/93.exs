**EXAMPLE FILE**

	verb_aux	SYM	noun	cm	quantifier;
	conj	demonstrative	noun	cm	quantifier;
	verb	conj	cardinal	noun	quantifier;
	pnoun	cm	cardinal	noun	quantifier;
	pnoun	cm	cardinal	adjective	quantifier;
	noun	cm	quantifier	adjective	quantifier;
	verb_aux	pn	adjective	noun	quantifier;
	SYM	pn	cm	demonstrative	pn;
	SYM	pn	noun	cm	quantifier;
	conj	noun	noun	cm	pn;
	SYM	cm	noun	cm	quantifier;
	cm	particle	cm	noun	pn;
	SYM	demonstrative	noun	adjective	quantifier;
	verb	verb_aux	adjective	noun	quantifier;
