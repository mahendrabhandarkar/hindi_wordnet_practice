**EXAMPLE FILE**

	noun	verb	verb_aux	SYM	P_wh;
