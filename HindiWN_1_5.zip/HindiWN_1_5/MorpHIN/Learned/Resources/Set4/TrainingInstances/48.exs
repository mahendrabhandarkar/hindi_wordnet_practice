**EXAMPLE FILE**

	verb	SYM	pn	demonstrative	inj;
	pnoun	cm	noun	adjective	noun;
	cm	nst	noun	demonstrative	noun;
	SYM	pnoun	noun	cm	noun;
