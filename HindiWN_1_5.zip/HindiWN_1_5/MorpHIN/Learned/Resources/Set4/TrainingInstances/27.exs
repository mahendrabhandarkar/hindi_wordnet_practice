**EXAMPLE FILE**

	verb_aux	pnoun	noun	cm	P_wh;
	noun	noun	adjective	noun	P_wh;
	demonstrative	noun	noun	cm	P_wh;
