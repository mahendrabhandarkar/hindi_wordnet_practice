**EXAMPLE FILE**

	verb_aux	SYM	particle	pnoun	cm;
	adjective	noun	noun	cm	cm;
	conj	pnoun	noun	cm	cm;
	adjective	verb	adjective	noun	cm;
	conj	pnoun	adjective	noun	cm;
