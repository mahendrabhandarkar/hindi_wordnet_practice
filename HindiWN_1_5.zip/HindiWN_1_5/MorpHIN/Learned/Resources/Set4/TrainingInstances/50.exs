**EXAMPLE FILE**

	noun	cm	adjective	verb	quantifier;
	noun	cm	noun	verb	quantifier;
	noun	cm	adjective	verb	quantifier;
	verb	pn	adjective	verb	quantifier;
	noun	cm	adjective	verb	quantifier;
	noun	cm	noun	verb	quantifier;
	cm	cm	adjective	verb	quantifier;
	verb_aux	pn	adjective	verb	quantifier;
	cm	cm	noun	verb	quantifier;
	cm	noun	adjective	verb	quantifier;
	pnoun	cm	noun	verb	quantifier;
	cm	noun	noun	verb	quantifier;
