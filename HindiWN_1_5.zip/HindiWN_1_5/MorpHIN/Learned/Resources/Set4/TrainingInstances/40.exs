**EXAMPLE FILE**

	pnoun	cm	adjective	noun	nst;
	conj	pn	noun	noun	nst;
	cardinal	noun	verb	verb_aux	adjective;
	conj	pn	quantifier	quantifier	nst;
	noun	cm	verb	SYM	nst;
