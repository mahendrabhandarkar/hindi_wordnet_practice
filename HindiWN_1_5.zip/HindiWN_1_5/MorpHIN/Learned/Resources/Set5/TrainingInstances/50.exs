**EXAMPLE FILE**

	noun	cm	adjective	verb	quantifier;
	noun	cm	noun	verb	quantifier;
	noun	cm	adjective	verb	quantifier;
	verb	pn	adjective	verb	quantifier;
	noun	cm	adjective	verb	quantifier;
	noun	cm	noun	verb	quantifier;
	cm	cm	adjective	verb	quantifier;
	verb_aux	pn	adjective	verb	quantifier;
	cm	cm	noun	verb	quantifier;
	cm	noun	adjective	neg	quantifier;
	noun	cm	adjective	noun	quantifier;
	verb_aux	conj	adverb	particle	intensifier;
	pnoun	pnoun	adjective	verb	quantifier;
	noun	verb	noun	verb	quantifier;
	SYM	pnoun	adjective	verb	quantifier;
	cm	pn	noun	verb	quantifier;
	cm	pn	noun	particle	quantifier;
	noun	cm	quantifier	noun	intensifier;
	SYM	noun	adjective	verb	quantifier;
