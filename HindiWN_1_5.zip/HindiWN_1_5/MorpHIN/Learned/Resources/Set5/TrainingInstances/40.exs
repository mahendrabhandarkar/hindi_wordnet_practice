**EXAMPLE FILE**

	pnoun	cm	adjective	noun	nst;
	conj	pn	noun	noun	nst;
	cardinal	noun	verb	verb_aux	adjective;
	pnoun	cm	adjective	noun	nst;
	pnoun	cm	adjective	noun	nst;
	conj	pn	cardinal	noun	nst;
