**EXAMPLE FILE**

	cm	noun	nst	noun	particle;
	SYM	noun	cm	adjective	particle;
	conj	pnoun	conj	adjective	particle;
	cardinal	adjective	adjective	noun	particle;
	P_wh	SYM	noun	noun	particle;
	conj	noun	cm	cardinal	cm;
