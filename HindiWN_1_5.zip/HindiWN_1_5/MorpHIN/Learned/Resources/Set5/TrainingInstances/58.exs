**EXAMPLE FILE**

	noun	cm	noun	pnoun	P_wh;
	noun	cm	verb	verb_aux	P_wh;
	pn	noun	verb	SYM	P_wh;
