**EXAMPLE FILE**

	pnoun	cm	cm	noun	nst;
	noun	cm	verb	verb_aux	nst;
	pnoun	cm	pn	verb	nst;
	noun	cm	verb	pn	cm;
	pnoun	pn	verb	verb_aux	nst;
	noun	cm	noun	conj	nst;
	noun	cm	pn	particle	nst;
	noun	cm	noun	verb	cm;
	cm	nst	cm	noun	nst;
	adverb	pn	verb	verb_aux	nst;
	conj	P_wh	verb	verb_aux	nst;
	noun	pn	cm	verb	noun;
	verb_aux	SYM	verb	pnoun	nst;
	noun	cm	verb	cm	nst;
