**EXAMPLE FILE**

	adjective	*	verb_aux	quantifier	*	verb_aux	a75	verb;
	adjective	*	verb_aux	conj	*	verb_aux	a75	verb;
