**EXAMPLE FILE**

	pnoun	*	noun	conj	*	noun	*	pn;
	conj	*	noun	verb_aux	a82	verb	*	pn;
	conj	*	noun	verb_aux	a82	verb	*	pn;
	particle	*	noun	cm	*	verb	*	pn;
	pnoun	*	noun	conj	*	verb	*	pn;
	cm	*	noun	cm	*	quantifier	*	pn;
	cm	*	ordinal	pnoun	*	pnoun	*	pn;
	noun	*	noun	cm	*	P_wh	*	pn;
	cm	*	noun	noun	a75	verb	*	pn;
	cm	*	pn	cm	*	adjective	*	pn;
	cm	*	verb_aux	noun	a84	verb_aux	*	verb;
	cm	*	adjective	pnoun	*	noun	*	pn;
	nst	*	noun	cm	*	adjective	*	pn;
	noun	*	quantifier	cm	*	noun	*	pn;
