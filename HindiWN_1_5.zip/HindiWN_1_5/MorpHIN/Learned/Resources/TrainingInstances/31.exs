**EXAMPLE FILE**

	pn	*	SYM	SYM	*	noun	*	adjective;
	noun	a76	verb	quantifier	*	verb_aux	*	adjective;
	conj	*	noun	verb	a57	neg	*	adjective;
	quantifier	*	verb	quantifier	*	particle	*	adjective;
	pn	*	noun	pn	*	verb	*	adjective;
