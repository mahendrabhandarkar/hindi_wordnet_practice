**EXAMPLE FILE**

	pnoun	*	noun	verb_aux	*	cm	*	P_wh;
	noun	*	adjective	noun	*	noun	*	P_wh;
	noun	*	verb	cm	*	cm	*	P_wh;
	conj	*	nst	verb	*	verb	*	P_wh;
	pn	*	SYM	conj	*	particle	*	P_wh;
	noun	*	noun	demonstrative	*	cm	*	P_wh;
