**EXAMPLE FILE**

	pnoun	cm	noun	cm	adjective;
	verb_aux	SYM	noun	cm	adjective;
	noun	cm	noun	cm	adjective;
	cm	pn	verb	noun	adjective;
	pnoun	conj	adjective	cm	adjective;
	cm	pn	adjective	cm	adjective;
	conj	pnoun	adjective	cm	adjective;
	pnoun	cm	adjective	noun	adjective;
	noun	cm	adjective	noun	cm;
