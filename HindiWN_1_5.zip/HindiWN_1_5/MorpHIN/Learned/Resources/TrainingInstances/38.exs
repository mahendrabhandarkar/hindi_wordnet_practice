**EXAMPLE FILE**

	cm	*	noun	noun	*	verb	*	adjective;
