**EXAMPLE FILE**

	cm	*	noun	cm	*	verb	*	P_wh;
	conj	*	pn	cm	*	demonstrative	*	P_wh;
	pn	*	noun	conj	*	verb	*	P_wh;
	noun	*	pnoun	noun	*	cm	*	P_wh;
	cm	*	verb	noun	a84	verb_aux	*	P_wh;
	cm	*	verb	verb	a34	verb_aux	*	P_wh;
	cm	*	verb	noun	*	verb_aux	*	P_wh;
	adverb	*	verb	SYM	*	pn	*	P_wh;
	particle	*	demonstrative	conj	*	noun	*	P_wh;
	adverb	*	verb	conj	*	SYM	*	P_wh;
	noun	*	noun	cm	*	verb	*	P_wh;
	pn	*	noun	cm	*	verb	*	P_wh;
	noun	*	verb	cm	*	SYM	*	P_wh;
