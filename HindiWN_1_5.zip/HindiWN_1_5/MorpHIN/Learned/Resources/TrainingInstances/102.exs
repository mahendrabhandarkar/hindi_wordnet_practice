**EXAMPLE FILE**

	conj	*	pn	verb	a51	cm	*	demonstrative;
	cm	*	noun	noun	a84	cm	*	quantifier;
	cm	*	noun	adverb	*	pnoun	*	quantifier;
	SYM	*	noun	*	*	noun	*	quantifier;
	cm	*	noun	noun	*	cm	*	quantifier;
	cm	*	noun	pnoun	*	quantifier	*	quantifier;
