**EXAMPLE FILE**

	cm	*	noun	pnoun	*	cm	*	adjective;
	SYM	*	noun	*	*	cm	*	adjective;
	cm	*	noun	noun	a84	cm	*	adjective;
	conj	*	adjective	pnoun	*	cm	*	adjective;
	pn	*	adjective	cm	*	cm	*	adjective;
	pnoun	*	adjective	conj	*	cm	*	adjective;
	cm	*	adjective	pnoun	*	noun	*	adjective;
	cm	*	cardinal	noun	a84	adjective	*	cm;
