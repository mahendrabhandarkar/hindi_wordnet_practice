**EXAMPLE FILE**

	noun	*	verb	demonstrative	*	verb_aux	*	adverb;
	pn	*	cm	conj	*	adjective	*	noun;
