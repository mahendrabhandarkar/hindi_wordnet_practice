**EXAMPLE FILE**

	verb	a29	verb_aux	noun	*	SYM	*	P_wh;
