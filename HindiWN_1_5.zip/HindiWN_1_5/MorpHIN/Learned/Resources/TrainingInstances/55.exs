**EXAMPLE FILE**

	conj	*	adjective	verb	*	noun	*	quantifier;
	noun	*	noun	adjective	a75	demonstrative	*	quantifier;
	cm	*	noun	pn	*	cm	*	quantifier;
	SYM	*	noun	noun	a84	cm	*	quantifier;
	noun	*	adjective	cm	*	noun	*	quantifier;
	nst	*	noun	cm	*	cm	*	quantifier;
	noun	a84	noun	adjective	a75	verb	*	quantifier;
