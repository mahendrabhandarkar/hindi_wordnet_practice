**EXAMPLE FILE**

	pnoun	*	pnoun	cardinal	*	cm	*	nst;
	conj	*	verb	noun	*	verb_aux	*	nst;
	cm	*	verb	pn	*	verb_aux	*	nst;
	quantifier	*	particle	particle	*	SYM	*	adjective;
	verb	*	pnoun	cm	*	cm	*	nst;
