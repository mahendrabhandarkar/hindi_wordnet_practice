**EXAMPLE FILE**

	conj	*	pnoun	noun	*	pnoun	*	noun;
	pnoun	*	cm	cm	*	verb	*	pnoun;
