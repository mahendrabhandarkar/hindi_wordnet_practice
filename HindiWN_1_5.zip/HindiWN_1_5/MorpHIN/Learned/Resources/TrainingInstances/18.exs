**EXAMPLE FILE**

	SYM	pn	demonstrative	pnoun	cm;
	noun	neg	conj	adjective	verb;
	cm	SYM	SYM	noun	cm;
