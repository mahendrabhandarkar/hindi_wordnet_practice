**EXAMPLE FILE**

	pn	*	verb	cm	*	pnoun	*	quantifier;
	particle	*	verb	cm	*	SYM	*	quantifier;
	cm	*	particle	noun	*	quantifier	*	quantifier;
	particle	a75	adverb	quantifier	*	noun	*	quantifier;
	cm	*	noun	cardinal	*	cm	*	quantifier;
	cm	*	noun	noun	*	cm	*	quantifier;
	cm	*	adjective	noun	*	verb	*	quantifier;
	cm	*	adjective	pnoun	*	verb	*	quantifier;
	cm	*	noun	noun	*	cm	*	quantifier;
	cm	*	noun	cardinal	*	cm	*	quantifier;
	cm	*	pnoun	noun	*	noun	*	quantifier;
	particle	*	noun	cm	*	SYM	*	quantifier;
	intensifier	*	noun	pn	*	verb	*	quantifier;
