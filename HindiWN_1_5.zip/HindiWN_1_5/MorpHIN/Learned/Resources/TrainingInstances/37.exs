**EXAMPLE FILE**

	cm	*	verb_aux	noun	a23	verb	a51	verb;
	noun	a33	neg	conj	*	SYM	*	adjective;
