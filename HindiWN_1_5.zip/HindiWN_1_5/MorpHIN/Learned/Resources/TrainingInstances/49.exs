**EXAMPLE FILE**

	cm	*	adjective	noun	*	verb	*	quantifier;
	cm	*	noun	noun	*	verb	*	quantifier;
	cm	*	adjective	noun	*	verb	*	quantifier;
	pn	*	adjective	verb	*	verb	*	quantifier;
	cm	*	adjective	noun	*	verb	*	quantifier;
	cm	*	noun	noun	*	verb	*	quantifier;
	cm	*	adjective	cm	*	verb	*	quantifier;
	pn	*	adjective	verb_aux	a57	verb	*	quantifier;
	cm	*	noun	cm	*	verb	*	quantifier;
	noun	*	adjective	cm	*	neg	*	quantifier;
	cm	*	adjective	noun	a75	noun	*	quantifier;
	conj	*	adverb	verb_aux	*	particle	*	intensifier;
	pnoun	*	adjective	pnoun	*	verb	*	quantifier;
	verb	*	noun	noun	*	verb	*	quantifier;
	pnoun	*	adjective	SYM	*	verb	*	quantifier;
	pn	*	noun	cm	*	verb	*	quantifier;
	pn	*	noun	cm	*	particle	*	quantifier;
	cm	*	quantifier	noun	*	noun	*	intensifier;
	noun	*	adjective	SYM	*	verb	*	quantifier;
	noun	*	adjective	cm	*	verb	*	quantifier;
	cm	*	noun	pnoun	*	verb	*	quantifier;
	noun	*	noun	cm	*	verb	*	quantifier;
