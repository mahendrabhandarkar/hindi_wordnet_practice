**EXAMPLE FILE**

	cm	noun	cm	adjective	adjective;
	verb	SYM	particle	adjective	adjective;
	verb	verb_aux	particle	pn	conj;
