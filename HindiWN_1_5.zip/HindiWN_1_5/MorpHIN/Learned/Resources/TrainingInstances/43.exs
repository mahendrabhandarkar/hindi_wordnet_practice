**EXAMPLE FILE**

	particle	*	verb_aux	nst	*	verb_aux	*	verb;
	pnoun	*	verb_aux	cm	*	verb_aux	*	verb;
	noun	a76	verb_aux	cm	*	verb_aux	*	verb;
	noun	*	verb_aux	noun	*	verb_aux	*	verb;
	adjective	*	particle	quantifier	*	verb_aux	*	verb;
	neg	*	verb_aux	noun	*	verb_aux	*	verb;
	noun	*	verb_aux	cm	*	verb_aux	*	verb;
	nst	*	verb_aux	pn	*	noun	*	verb;
	particle	*	verb_aux	pn	*	pn	*	verb;
	noun	*	verb_aux	cm	*	verb_aux	*	verb;
	cm	*	verb_aux	noun	a75	quantifier	*	verb;
