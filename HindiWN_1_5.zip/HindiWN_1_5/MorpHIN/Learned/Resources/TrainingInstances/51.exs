**EXAMPLE FILE**

	nst	*	noun	cm	*	noun	*	cm;
	conj	*	noun	adverb	*	adjective	*	cm;
	noun	*	noun	demonstrative	*	noun	*	cm;
	verb	a12	pnoun	cm	*	noun	*	adverb;
	pn	*	noun	conj	*	cm	*	adverb;
