**EXAMPLE FILE**

	noun	*	noun	noun	*	cm	*	particle;
