**EXAMPLE FILE**

	SYM	noun	pnoun	conj	pnoun;
