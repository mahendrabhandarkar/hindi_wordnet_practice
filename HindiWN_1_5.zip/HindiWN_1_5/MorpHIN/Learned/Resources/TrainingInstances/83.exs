**EXAMPLE FILE**

	cardinal	*	cm	cm	*	adjective	*	pnoun;
	cardinal	*	cm	noun	*	pnoun	*	pnoun;
	cardinal	*	cm	noun	*	pnoun	*	pnoun;
