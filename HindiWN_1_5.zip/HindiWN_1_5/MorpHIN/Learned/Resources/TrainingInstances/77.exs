**EXAMPLE FILE**

	verb_aux	a28	conj	verb	*	demonstrative	a69	verb_aux;
	verb_aux	a51	conj	verb	*	pn	a69	verb_aux;
	adjective	*	SYM	quantifier	*	*	*	verb;
	verb_aux	a51	SYM	verb	*	*	a69	verb_aux;
	adjective	*	SYM	cm	*	*	*	verb;
