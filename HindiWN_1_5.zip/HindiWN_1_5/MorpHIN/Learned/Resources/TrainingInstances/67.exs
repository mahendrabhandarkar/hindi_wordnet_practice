**EXAMPLE FILE**

	SYM	*	ordinal	*	*	noun	*	pn;
	SYM	*	demonstrative	verb_aux	a82	noun	*	pn;
	verb	*	demonstrative	pnoun	*	noun	*	pn;
	verb_aux	a82	pn	verb_aux	a75	noun	*	pn;
	verb	*	adjective	cm	*	noun	*	pn;
	verb_aux	a19	adjective	verb	*	pnoun	*	pn;
	verb	*	demonstrative	noun	*	noun	*	pn;
	pn	*	verb	pn	*	noun	*	pn;
	cm	*	quantifier	pnoun	*	noun	*	pn;
	verb	*	demonstrative	noun	*	noun	*	pn;
	SYM	*	pn	verb_aux	*	cardinal	*	pn;
	SYM	*	cm	SYM	*	pn	*	pn;
	SYM	*	cm	*	*	demonstrative	*	pn;
	verb	*	verb	noun	*	pn	*	pn;
	verb_aux	a82	pn	verb	*	noun	*	pn;
	verb_aux	a57	adjective	verb	*	noun	*	pn;
