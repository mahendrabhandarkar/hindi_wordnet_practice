**EXAMPLE FILE**

	SYM	*	pnoun	*	*	adjective	*	conj;
