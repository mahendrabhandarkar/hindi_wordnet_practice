**EXAMPLE FILE**

	cm	*	conj	noun	a75	particle	*	pn;
	cm	*	particle	noun	a84	verb	*	pn;
	SYM	*	demonstrative	*	*	noun	*	pn;
