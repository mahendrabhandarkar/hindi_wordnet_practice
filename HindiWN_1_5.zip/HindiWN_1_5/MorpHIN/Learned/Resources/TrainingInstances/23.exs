**EXAMPLE FILE**

	noun	cm	adjective	noun	cm;
	noun	cm	noun	verb	cm;
	noun	cm	noun	verb	cm;
	noun	cm	cardinal	noun	cm;
	noun	cm	noun	verb	cm;
	noun	cm	noun	verb	cm;
	noun	cm	adjective	noun	cm;
	pn	pn	verb	conj	cm;
	pnoun	cm	adjective	noun	cm;
	pnoun	cm	verb	cm	cm;
	noun	cm	adjective	noun	cm;
	pnoun	cm	verb	noun	cm;
	pnoun	cm	cardinal	SYM	cm;
	pnoun	cm	pn	noun	cm;
	pnoun	cm	noun	noun	cm;
	pnoun	cm	noun	verb	cm;
	SYM	pn	noun	noun	cm;
	noun	cm	verb	verb_aux	adjective;
	pnoun	cm	verb	cm	adjective;
	pnoun	cm	adjective	noun	cm;
	pnoun	cm	noun	cm	cm;
	cm	pn	quantifier	adjective	cm;
	SYM	pn	quantifier	particle	cm;
	noun	cm	noun	verb	cm;
	pnoun	cm	noun	adjective	cm;
