**EXAMPLE FILE**

	verb_aux	SYM	nst	noun	adverb;
	verb_aux	SYM	demonstrative	noun	adverb;
	noun	verb	demonstrative	noun	pn;
	verb_aux	SYM	pn	cardinal	pn;
	SYM	SYM	particle	pn	pn;
	verb	SYM	particle	demonstrative	pn;
	noun	verb	verb	pn	pn;
	verb	verb_aux	pn	noun	pn;
	verb	verb_aux	adjective	noun	pn;
