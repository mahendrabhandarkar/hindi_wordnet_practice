**EXAMPLE FILE**

	cardinal	noun	verb	verb_aux	adjective;
	pnoun	cm	adjective	noun	nst;
	pnoun	cm	adjective	noun	nst;
	conj	pn	cardinal	noun	nst;
	conj	pn	quantifier	quantifier	nst;
	noun	cm	verb	SYM	nst;
