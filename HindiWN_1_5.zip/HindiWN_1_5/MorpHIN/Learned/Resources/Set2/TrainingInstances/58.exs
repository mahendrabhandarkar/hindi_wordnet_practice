**EXAMPLE FILE**

	noun	cm	noun	cm	cardinal;
	conj	noun	adjective	noun	cardinal;
	verb	adjective	cardinal	noun	cardinal;
	noun	cm	cardinal	cm	cardinal;
	cm	nst	noun	particle	cardinal;
	noun	cm	noun	nst	cardinal;
	verb_aux	pn	cardinal	noun	cardinal;
	verb_aux	conj	cardinal	noun	cardinal;
	verb_aux	conj	noun	cm	cardinal;
	pnoun	pnoun	noun	pnoun	cardinal;
	adjective	SYM	noun	cm	cardinal;
	pnoun	cm	noun	noun	cardinal;
	cm	pn	noun	cm	cardinal;
	cm	cm	adjective	noun	cardinal;
	cm	adverb	noun	noun	cardinal;
	cm	quantifier	noun	cm	cardinal;
	pnoun	cm	noun	noun	cardinal;
	cm	pn	pnoun	cardinal	cardinal;
