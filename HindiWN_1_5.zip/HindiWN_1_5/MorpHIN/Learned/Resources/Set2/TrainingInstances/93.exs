**EXAMPLE FILE**

	cm	pnoun	cm	verb	pnoun;
