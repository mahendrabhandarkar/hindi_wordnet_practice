**EXAMPLE FILE**

	pnoun	cm	cm	noun	nst;
	noun	cm	verb	verb_aux	nst;
	pnoun	cm	pn	verb	nst;
	noun	cm	noun	verb	cm;
	cm	nst	cm	noun	nst;
	adverb	pn	verb	verb_aux	nst;
	conj	P_wh	verb	verb_aux	nst;
	noun	pn	cm	verb	noun;
	verb_aux	SYM	verb	pnoun	nst;
	noun	cm	verb	cm	nst;
	adjective	noun	verb	verb_aux	nst;
	cardinal	cm	verb	SYM	nst;
	cm	noun	verb	verb_aux	cm;
	pnoun	cm	demonstrative	noun	cm;
	cm	noun	verb	verb_aux	cm;
	pnoun	cm	noun	cm	cm;
	noun	cm	verb	cm	nst;
