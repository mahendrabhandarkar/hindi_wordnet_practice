**EXAMPLE FILE**

	SYM	pn	demonstrative	pnoun	cm;
