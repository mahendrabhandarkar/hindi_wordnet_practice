**EXAMPLE FILE**

	verb	conj	adjective	noun	quantifier;
	noun	SYM	noun	cm	adverb;
	cm	noun	adjective	noun	adverb;
	cm	nst	noun	cm	adverb;
	adjective	noun	noun	verb	adverb;
