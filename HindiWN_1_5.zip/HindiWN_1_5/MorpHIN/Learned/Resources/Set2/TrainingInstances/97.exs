**EXAMPLE FILE**

	verb	SYM	noun	noun	quantifier;
	noun	cm	noun	cm	quantifier;
	pnoun	cm	noun	quantifier	quantifier;
