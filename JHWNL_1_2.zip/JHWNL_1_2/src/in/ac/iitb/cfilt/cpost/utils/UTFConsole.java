package in.ac.iitb.cfilt.cpost.utils;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class UTFConsole {
	public static PrintStream out = null;
	static{
		try {
			out = new PrintStream(System.out, true, "UTF8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
