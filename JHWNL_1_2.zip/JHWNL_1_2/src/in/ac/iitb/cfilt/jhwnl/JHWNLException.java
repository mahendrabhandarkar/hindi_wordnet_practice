// CFILT LAB
// Author: Manish Sinha
// Base level exception used by JWNL. Tries to resolve the message using JWNL.resolveMessage.
// *******************************************************************************************************************8
package in.ac.iitb.cfilt.jhwnl;
//Base level exception used by JWNL. Tries to resolve the message using JWNL.resolveMessage.


public class JHWNLException extends Exception {
  
	private static final long serialVersionUID = -2659731301692536106L;

	public JHWNLException() {}

}
