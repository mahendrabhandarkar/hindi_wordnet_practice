// CFILT LAB
// Author: Manish Sinha
// Base level runtime exception used by JWNL. Tries to resolve the message using JWNL.resolveMessage.
// **************************************************************************************************************
package in.ac.iitb.cfilt.jhwnl;



public class JHWNLRuntimeException extends RuntimeException   {

	private static final long serialVersionUID = -8723566333619042777L;

	public JHWNLRuntimeException() {}

}
